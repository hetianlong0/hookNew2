package com.taobao.dexposed;

import android.app.Application;

public class DexposedSampleApplication extends Application {  

    @Override  
    public void onCreate() {
        super.onCreate();
    }  
}  
