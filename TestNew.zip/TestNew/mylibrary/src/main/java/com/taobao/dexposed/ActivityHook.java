package com.taobao.dexposed;

import android.app.Activity;
import android.os.Build;
import android.util.Log;

import com.lingcloud.apptrace.sdk.DclingCloudAgent;
import com.lingcloud.apptrace.sdk.Utils;
import com.taobao.android.dexposed.XC_MethodHook;
import com.taobao.android.dexposed.XC_MethodHook.Unhook;
import com.taobao.android.dexposed.DexposedBridge;

public class ActivityHook {

	private static ActivityHook activityHook;
	private static final String TAG = "ActivityHook";

	static DclingCloudAgent lingAgent_;
	
	// stop 执行时间
	public long stopStartTime;
	public long stopEndTime;

	// start 执行时间
	public long startStartTime;
	public long startEndTime;

	// http连接的网络地址
	// public String connectionUrl;
	// public String executeUrl;
	//
	// public String executeMethod;
	// public String connectionMethod;

	synchronized public static ActivityHook instance(DclingCloudAgent agent) {
		if (activityHook == null) {
			activityHook = new ActivityHook();
			lingAgent_ = agent;
		}

		return activityHook;
	}

	private boolean isEnable() {
		if (Build.VERSION.SDK_INT >= 9 && Build.VERSION.SDK_INT <= 22) {
			return true;
		} else
			return false;
	}

	private ActivityHook() {

		if (!isEnable())
			return;

	}

	private void hook() {
		Class<?> cls = null;
		try {
			cls = Class.forName("android.app.Activity");
		} catch (ClassNotFoundException e) {
			Log.w(TAG, "fail to android.app.Activity");
			e.printStackTrace();
			return;
		}

		XC_MethodHook mehodHook = new XC_MethodHook() {
			@Override
			protected void afterHookedMethod(MethodHookParam param)
					throws Throwable {
				startEndTime = System.currentTimeMillis();
//				Log.e(TAG,
//						"android.app.Activity start afterHookedMethod  startEndTime");
			}

			protected void beforeHookedMethod(MethodHookParam param)
					throws Throwable {
				startStartTime = System.currentTimeMillis();
				Activity host = (Activity) param.thisObject;
				Log.e(TAG,
						"android.app.Activity before startStartTime. Activity's name is: "
								+ host.getClass().getName());
				lingAgent_.onStart(host);
//				Utils.printStackInfo();
			}
		};

		onStart = DexposedBridge.findAndHookMethod(cls, "onStart", mehodHook);

		XC_MethodHook mehodHookStop = new XC_MethodHook() {
			@Override
			protected void afterHookedMethod(MethodHookParam param)
					throws Throwable {
				stopEndTime = System.currentTimeMillis();
				Activity host = (Activity) param.thisObject;
				Log.e(TAG,
						"android.app.Activity stop afterHookedMethod. Activity's name is: "
								+ host.getClass().getName());
			}

			protected void beforeHookedMethod(MethodHookParam param)
					throws Throwable {
				stopStartTime = System.currentTimeMillis();
				Activity host = (Activity)param.thisObject;
				Log.e(TAG,
						"android.app.Activity onStop beforeHookedMethod. Activity's name is: "
								+ host.getClass().getName());
				lingAgent_.onStop();
//				Utils.printStackInfo();
			}
		};

		onStop = DexposedBridge.findAndHookMethod(cls, "onStop", mehodHookStop);

	}

	private void unhook() {
		if (onStart != null) {
			onStart.unhook();
			onStart = null;
		}

		if (onStop != null) {
			onStop.unhook();
			onStop = null;
		}
	}

	private Unhook onStart;
	private Unhook onStop;

	private boolean isStart = false;

	public void start() {
		if (!isEnable())
			return;

		if (isStart)
			return;

		hook();

		isStart = true;
	}

	public void stop() {
		if (!isEnable())
			return;

		if (!isStart)
			return;

		unhook();

		isStart = false;
	}
}
