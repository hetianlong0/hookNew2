package com.taobao.dexposed;

import android.os.Build;
import android.util.Log;
import android.view.View;

import com.lingcloud.apptrace.sdk.DclingCloudAgent;
import com.lingcloud.apptrace.sdk.Utils;
import com.taobao.android.dexposed.XC_MethodHook;
import com.taobao.android.dexposed.XC_MethodHook.Unhook;
import com.taobao.android.dexposed.DexposedBridge;

public class ClickHook {

	private static ClickHook clickHook;
	private static final String TAG = "ClickHook";

	static DclingCloudAgent lingAgent_;
	
	// stop 执行时间
	public long stopStartTime;
	public long stopEndTime;

	// start 执行时间
	public long startStartTime;
	public long startEndTime;

	// http连接的网络地址
	// public String connectionUrl;
	// public String executeUrl;
	//
	// public String executeMethod;
	// public String connectionMethod;

	synchronized public static ClickHook instance(DclingCloudAgent agent) {
		if (clickHook == null) {
			clickHook = new ClickHook();
			lingAgent_ = agent;
		}

		return clickHook;
	}

	private boolean isEnable() {
		if (Build.VERSION.SDK_INT >= 9 && Build.VERSION.SDK_INT <= 22) {
			return true;
		} else
			return false;
	}

	private ClickHook() {

		if (!isEnable())
			return;

	}

	private void hook() {
		Class<?> cls = null;
		try {
			cls = Class.forName("android.view.View");
		} catch (ClassNotFoundException e) {
			Log.w(TAG, "fail to android.app.Activity");
			e.printStackTrace();
			return;
		}

		XC_MethodHook mehodHook = new XC_MethodHook() {
			@Override
			protected void afterHookedMethod(MethodHookParam param)
					throws Throwable {
				startEndTime = System.currentTimeMillis();
			}

			protected void beforeHookedMethod(MethodHookParam param)
					throws Throwable {
				startStartTime = System.currentTimeMillis();
				View host = (View) param.thisObject;
				Log.e(TAG,
						"View clicked!  View's name is: " + host.getClass().getName()
						+" id = " + host.getId());

				lingAgent_.recordEvent("ButtonClick", 1);
			}
		};

		onPerformClick = DexposedBridge.findAndHookMethod(cls, "performClick", mehodHook);

		XC_MethodHook mehodHookStop = new XC_MethodHook() {
			@Override
			protected void afterHookedMethod(MethodHookParam param)
					throws Throwable {
				stopEndTime = System.currentTimeMillis();
				View host = (View) param.thisObject;
				Log.e(TAG,
						"View clicked!  View's name is: " + host.getClass().getName()
						+" id = " + host.getId());
			}

			protected void beforeHookedMethod(MethodHookParam param)
					throws Throwable {
				stopStartTime = System.currentTimeMillis();
				View host = (View) param.thisObject;
				Log.e(TAG,
						"View clicked!  View's name is: " + host.getClass().getName()
						+" id = " + host.getId());
				
				lingAgent_.recordEvent("ButtonLongClick", 1);
			}
		};

		onLongClick = DexposedBridge.findAndHookMethod(cls, "performLongClick", mehodHookStop);
	}

	private void unhook() {
		if (onPerformClick != null) {
			onPerformClick.unhook();
			onPerformClick = null;
		}

		if (onLongClick != null) {
			onLongClick.unhook();
			onLongClick = null;
		}
	}

	private Unhook onPerformClick;
	private Unhook onLongClick;

	private boolean isStart = false;

	public void start() {
		if (!isEnable())
			return;

		if (isStart)
			return;

		hook();

		isStart = true;
	}

	public void stop() {
		if (!isEnable())
			return;

		if (!isStart)
			return;

		unhook();

		isStart = false;
	}
}
