package com.lingcloud.apptrace.sdk;

public class NetInfors {
	//获得本机IP地址
	public String ip;
	//获得网络类型
	public String net_type;
}
